# {{cookiecutter.project_name}}

Created by: {{cookiecutter.full_name}} ({{cookiecutter.email}})

{{cookiecutter.description}}
