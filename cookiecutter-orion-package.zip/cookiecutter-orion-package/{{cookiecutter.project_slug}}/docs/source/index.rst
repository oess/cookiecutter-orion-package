##########################################################
{{cookiecutter.project_name}} Documentation
##########################################################

Documentation for {{cookiecutter.project_name}} created by {{cookiecutter.full_name}}.

{{cookiecutter.description}}

Contents:

.. toctree::
   :maxdepth: 2

   floes/floes.rst
   cubes/cubes.rst

*   :ref:`genindex`
