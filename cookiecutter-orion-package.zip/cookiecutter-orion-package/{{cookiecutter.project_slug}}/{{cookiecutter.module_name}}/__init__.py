__version__ = "{{cookiecutter.version}}"
